# BARikan Event Booking Landing Page — Setup Guide

## Included

- Responsive landing page for mobile, tablet, and desktop
- BARikan Events Venue + You're my BOSS Food and Catering Services + BOSS BARikan & Resto sections
- Event inquiry / booking form
- Google Sheets backend via Google Apps Script
- Booking reference ID
- UTM tracking fields for Meta ads
- Booking status column (`New Inquiry` by default)
- Optional admin and customer email notifications

## 1. Create the Google Sheet

1. Open Google Sheets and create a new spreadsheet.
2. Copy the spreadsheet ID from the Sheet URL.
   - Example URL: `https://docs.google.com/spreadsheets/d/SPREADSHEET_ID/edit`
3. You do **not** need to create the headers manually. The Apps Script creates the `Bookings` sheet and headers automatically on the first valid submission.

The created columns are:

`Booking ID | Date Submitted | Customer Name | Mobile | Email | Event Type | Event Date | Preferred Time | Guests | Services Needed | Notes | Consent | Booking Status | Source | UTM Source | UTM Medium | UTM Campaign | UTM Content | Page URL | Client Submitted At`

## 2. Connect Google Apps Script

1. In the Google Sheet, go to **Extensions > Apps Script**.
2. Delete the existing sample code.
3. Open `apps-script/Code.gs` from this website package and copy all of its code.
4. Paste it into Apps Script.
5. Replace:

   `PASTE_YOUR_GOOGLE_SHEET_ID_HERE`

   with the actual Google Sheet ID.
6. In Apps Script, go to **Project Settings** and set the timezone to **Asia/Manila**.
7. Click **Deploy > New deployment**.
8. Select **Web app**.
9. Set:
   - Execute as: **Me**
   - Who has access: **Anyone**
10. Click **Deploy** and approve the requested Google permissions.
11. Copy the Web App URL ending in `/exec`.

## 3. Connect the landing page

Open:

`assets/js/config.js`

Replace:

`PASTE_YOUR_GOOGLE_APPS_SCRIPT_WEB_APP_URL_HERE`

with the Web App `/exec` URL.

Then change:

`demoMode: true`

to:

`demoMode: false`

## 4. Test before publishing

1. Open the website using a local server or deploy it to GitHub Pages.
2. Submit a test event inquiry.
3. Check the Google Sheet.
4. Confirm that a new row appears in the `Bookings` sheet.
5. Change the test row's `Booking Status` from `New Inquiry` to any internal status you use, such as:
   - Contacted
   - Pending
   - Confirmed
   - Cancelled

## 5. Optional email notification

Inside `apps-script/Code.gs`:

- Set `SEND_ADMIN_EMAIL: true` to email `bossbarikanresto@gmail.com` for every inquiry.
- Set `SEND_CUSTOMER_EMAIL: true` to send a basic inquiry receipt to customers who provide an email address.

After changing Apps Script code, create a **new Web App deployment version** or edit the deployment and deploy the latest version.

## 6. GitHub Pages deployment

1. Create a GitHub repository.
2. Upload the contents of this folder. `index.html` must stay in the repository root.
3. Go to **Settings > Pages**.
4. Under Build and deployment, choose **Deploy from a branch**.
5. Select the main branch and `/root`.
6. Save.

## Meta Ads tracking example

Use a landing page URL like:

`https://YOURDOMAIN.com/?utm_source=facebook&utm_medium=paid_social&utm_campaign=barikan_event_booking&utm_content=creative_1`

For Creative 2, change `utm_content=creative_2`.
For Creative 3, change `utm_content=creative_3`.

The values are saved automatically in the Google Sheet so you can compare which ad creative generated each inquiry.

## Important

The page labels submissions as **event inquiries**, not instantly confirmed bookings. Final confirmation should only happen after the team checks the date and contacts the customer.
