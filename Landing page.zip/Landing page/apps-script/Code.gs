/**
 * BARikan Event Booking - Google Apps Script backend
 *
 * SETUP:
 * 1. Create/open a Google Sheet.
 * 2. Extensions > Apps Script.
 * 3. Replace Code.gs with this file.
 * 4. Update SPREADSHEET_ID below.
 * 5. Deploy > New deployment > Web app.
 * 6. Execute as: Me. Who has access: Anyone.
 * 7. Copy the /exec URL to assets/js/config.js.
 */

const CONFIG = {
  SPREADSHEET_ID: 'PASTE_YOUR_GOOGLE_SHEET_ID_HERE',
  SHEET_NAME: 'Bookings',
  ADMIN_EMAIL: 'bossbarikanresto@gmail.com',
  SEND_ADMIN_EMAIL: false,
  SEND_CUSTOMER_EMAIL: false
};

const HEADERS = [
  'Booking ID',
  'Date Submitted',
  'Customer Name',
  'Mobile',
  'Email',
  'Event Type',
  'Event Date',
  'Preferred Time',
  'Guests',
  'Services Needed',
  'Notes',
  'Consent',
  'Booking Status',
  'Source',
  'UTM Source',
  'UTM Medium',
  'UTM Campaign',
  'UTM Content',
  'Page URL',
  'Client Submitted At'
];

function doGet() {
  return jsonOutput_({
    ok: true,
    service: 'BARikan Event Booking API',
    message: 'Web app is running.'
  });
}

function doPost(e) {
  try {
    const payload = parsePayload_(e);
    validatePayload_(payload);

    const lock = LockService.getScriptLock();
    lock.waitLock(20000);

    try {
      const sheet = getBookingSheet_();
      const bookingId = clean_(payload.bookingId) || createBookingId_();
      const submittedAt = new Date();

      sheet.appendRow([
        bookingId,
        submittedAt,
        clean_(payload.fullName),
        clean_(payload.mobile),
        clean_(payload.email),
        clean_(payload.eventType),
        clean_(payload.eventDate),
        clean_(payload.eventTime),
        numberOrText_(payload.guestCount),
        clean_(payload.services),
        clean_(payload.notes),
        clean_(payload.consent),
        'New Inquiry',
        clean_(payload.source),
        clean_(payload.utmSource),
        clean_(payload.utmMedium),
        clean_(payload.utmCampaign),
        clean_(payload.utmContent),
        clean_(payload.pageUrl),
        clean_(payload.submittedAtClient)
      ]);

      formatLastRow_(sheet);

      if (CONFIG.SEND_ADMIN_EMAIL && CONFIG.ADMIN_EMAIL) {
        sendAdminEmail_(payload, bookingId);
      }

      if (CONFIG.SEND_CUSTOMER_EMAIL && payload.email) {
        sendCustomerEmail_(payload, bookingId);
      }

      return jsonOutput_({ ok: true, bookingId: bookingId });
    } finally {
      lock.releaseLock();
    }
  } catch (error) {
    console.error(error);
    return jsonOutput_({ ok: false, error: error.message || String(error) });
  }
}

function parsePayload_(e) {
  if (!e) throw new Error('No request received.');

  if (e.postData && e.postData.contents) {
    try {
      return JSON.parse(e.postData.contents);
    } catch (jsonError) {
      // Fall back to normal form parameters.
    }
  }

  return e.parameter || {};
}

function validatePayload_(data) {
  const required = ['fullName', 'mobile', 'eventType', 'eventDate', 'guestCount', 'services'];
  const missing = required.filter(function (key) {
    return !clean_(data[key]);
  });

  if (missing.length) {
    throw new Error('Missing required fields: ' + missing.join(', '));
  }

  const guestCount = Number(data.guestCount);
  if (!Number.isFinite(guestCount) || guestCount < 1) {
    throw new Error('Invalid guest count.');
  }
}

function getBookingSheet_() {
  if (!CONFIG.SPREADSHEET_ID || CONFIG.SPREADSHEET_ID.indexOf('PASTE_YOUR_') === 0) {
    throw new Error('Please set CONFIG.SPREADSHEET_ID in Code.gs.');
  }

  const ss = SpreadsheetApp.openById(CONFIG.SPREADSHEET_ID);
  let sheet = ss.getSheetByName(CONFIG.SHEET_NAME);

  if (!sheet) sheet = ss.insertSheet(CONFIG.SHEET_NAME);

  if (sheet.getLastRow() === 0) {
    sheet.getRange(1, 1, 1, HEADERS.length).setValues([HEADERS]);
    sheet.setFrozenRows(1);
    sheet.getRange(1, 1, 1, HEADERS.length)
      .setFontWeight('bold')
      .setBackground('#8f0f12')
      .setFontColor('#ffffff');
    sheet.autoResizeColumns(1, HEADERS.length);
  }

  return sheet;
}

function createBookingId_() {
  const tz = Session.getScriptTimeZone() || 'Asia/Manila';
  const dateKey = Utilities.formatDate(new Date(), tz, 'yyyyMMdd');
  const properties = PropertiesService.getScriptProperties();
  const key = 'BOOKING_SEQ_' + dateKey;
  const next = Number(properties.getProperty(key) || 0) + 1;
  properties.setProperty(key, String(next));
  return 'BRK-' + dateKey + '-' + String(next).padStart(3, '0');
}

function formatLastRow_(sheet) {
  const row = sheet.getLastRow();
  if (row <= 1) return;

  sheet.getRange(row, 2).setNumberFormat('yyyy-mm-dd hh:mm:ss');
  sheet.getRange(row, 7).setNumberFormat('@');
  sheet.getRange(row, 13).setBackground('#fff2cc');
}

function sendAdminEmail_(data, bookingId) {
  const subject = 'New BARikan Event Inquiry - ' + bookingId;
  const body = [
    'A new event inquiry was submitted.',
    '',
    'Booking ID: ' + bookingId,
    'Name: ' + clean_(data.fullName),
    'Mobile: ' + clean_(data.mobile),
    'Email: ' + clean_(data.email),
    'Event: ' + clean_(data.eventType),
    'Preferred Date: ' + clean_(data.eventDate),
    'Preferred Time: ' + clean_(data.eventTime),
    'Guests: ' + clean_(data.guestCount),
    'Services: ' + clean_(data.services),
    '',
    'Notes:',
    clean_(data.notes)
  ].join('\n');

  MailApp.sendEmail(CONFIG.ADMIN_EMAIL, subject, body);
}

function sendCustomerEmail_(data, bookingId) {
  const subject = 'We received your BARikan event inquiry - ' + bookingId;
  const body = [
    'Hi ' + clean_(data.fullName) + ',',
    '',
    'Thank you for sending your event inquiry.',
    'Reference number: ' + bookingId,
    '',
    'Your inquiry is not yet a confirmed booking. Our team will check availability and contact you about the next steps.',
    '',
    'BARikan Event Booking',
    '0917 588 2281',
    'PAJ Building, 35 M. Almeda Street, San Roque, Pateros, 1620'
  ].join('\n');

  MailApp.sendEmail(clean_(data.email), subject, body);
}

function clean_(value) {
  if (value === null || value === undefined) return '';
  return String(value).trim().slice(0, 5000);
}

function numberOrText_(value) {
  const n = Number(value);
  return Number.isFinite(n) ? n : clean_(value);
}

function jsonOutput_(data) {
  return ContentService
    .createTextOutput(JSON.stringify(data))
    .setMimeType(ContentService.MimeType.JSON);
}
